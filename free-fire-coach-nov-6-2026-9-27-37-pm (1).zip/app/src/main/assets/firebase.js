/**
 * FREE FIRE COACH - Firebase Configuration & Database Layer
 * Handles Firebase Auth & Firestore with seamless offline / persistent fallback.
 */

// Production Firebase Configuration Placeholder (Update with your Firebase project keys if desired)
const firebaseConfig = {
  apiKey: "AIzaSyDummyKeyForFreeFireCoachPlatform9988",
  authDomain: "free-fire-coach.firebaseapp.com",
  projectId: "free-fire-coach",
  storageBucket: "free-fire-coach.appspot.com",
  messagingSenderId: "982736451234",
  appId: "1:982736451234:web:8f7e6d5c4b3a2109"
};

// Initialize Firebase SDK if available
let firebaseApp = null;
let firebaseAuth = null;
let firebaseFirestore = null;

try {
  if (typeof firebase !== 'undefined' && firebase.initializeApp) {
    firebaseApp = firebase.initializeApp(firebaseConfig);
    if (firebase.auth) firebaseAuth = firebase.auth();
    if (firebase.firestore) firebaseFirestore = firebase.firestore();
  }
} catch (e) {
  console.warn("Live Firebase initialized in local database mode:", e.message);
}

// -------------------------------------------------------------
// Unified Database Engine (FF_DB)
// Syncs to Firestore when available and persists in LocalStorage/IndexedDB
// -------------------------------------------------------------

const DEFAULT_APP_SETTINGS = {
  bankName: "Moniepoint MFB",
  accountNumber: "5174001034",
  accountName: "FREE FIRE COACH VENTURES",
  supportEmail: "support@freefirecoach.com",
  contactPhone: "+234 812 345 6789",
  announcement: "🔥 OB45 Update: New one-tap drag algorithm & Shotgun crosshair calibration is now live!"
};

const DEFAULT_PLANS = [
  {
    id: "weekly",
    name: "Weekly Premium",
    priceUSD: 2.99,
    priceNGN: 3500,
    durationDays: 7,
    popular: false,
    active: true,
    features: [
      "Unlimited Sensitivity Generations",
      "Advanced Weapon-Specific Tuning",
      "Exclusive Headshot Training Lessons",
      "Recommended DPI & Custom HUD Guides",
      "Save Up to 5 Sensitivity Profiles"
    ]
  },
  {
    id: "monthly",
    name: "Monthly Premium",
    priceUSD: 7.99,
    priceNGN: 8500,
    durationDays: 30,
    popular: true,
    active: true,
    features: [
      "Everything in Weekly Plan",
      "Personalized 7-Day Aim Routine",
      "Pro Clash Squad & BR Tactics",
      "Advanced Weapon Recoil Control Guide",
      "Save Up to 15 Sensitivity Profiles",
      "Priority Payment Verification"
    ]
  },
  {
    id: "lifetime",
    name: "Lifetime VIP",
    priceUSD: 19.99,
    priceNGN: 25000,
    durationDays: 3650, // 10 years
    popular: false,
    active: true,
    features: [
      "Lifetime Unrestricted VIP Access",
      "All Future Academy Masterclasses",
      "VIP Grandmaster Discord Role / Badge",
      "Unlimited Sensitivity Profiles",
      "Direct 1-on-1 Aim Review & Coaching Tips",
      "One-time Payment - Zero Recurring Fees"
    ]
  }
];

const DEFAULT_LESSONS = [
  {
    id: "lesson_1",
    title: "How to Improve Headshots",
    category: "aiming",
    difficulty: "Beginner",
    duration: "10 mins",
    isPremium: false,
    summary: "Master the fundamental crosshair placement and drag physics to connect crisp red numbers consistently.",
    instructions: [
      "1. Keep crosshair at shoulder level while sprinting, never pointing at the ground.",
      "2. Understand White Crosshair vs Red Crosshair: dragging when the crosshair is white near the target head generates 35% higher auto-headshot chance.",
      "3. Execute the Straight Drag: Swipe your right fire button upward with uniform acceleration towards the sky.",
      "4. Do not hold the fire button continuously for more than 4-5 bullets to avoid bullet bloom and recoil."
    ],
    exercises: [
      "Training Ground: Stand 10 meters from the stationary bot. Land 30 consecutive clean headshots using SCAR or M4A1 without crouching.",
      "Sprint & Stop Drill: Run in circle, stop for 0.5s, center crosshair, drag headshot in 1 fluid motion."
    ]
  },
  {
    id: "lesson_2",
    title: "How to Master Drag Headshots",
    category: "aiming",
    difficulty: "Intermediate",
    duration: "15 mins",
    isPremium: false,
    summary: "Learn the secrets of the J-Drag, Straight-Up Drag, and Tick-Drag techniques based on enemy movement vectors.",
    instructions: [
      "1. The J-Drag (for moving targets): Pull the fire button down slightly, then curve up in the shape of a 'J' towards the enemy's moving direction.",
      "2. Straight Drag (for stationary or straight-rushing targets): Pull straight up directly towards the target's head.",
      "3. Drag Speed Dynamics: If the enemy is close (<5m), drag furiously fast with full thumb stroke. If far (>25m), perform a gentle, slow drag.",
      "4. Ensure your fire button size is between 42% - 50% to give your thumb ample upward dragging runway on screen."
    ],
    exercises: [
      "Claw practice: Practice the J-Drag on moving target dummies for 10 minutes until thumb muscle memory forms.",
      "Clash Squad Round 1: Only use USP or G18 aiming exclusively for the head."
    ]
  },
  {
    id: "lesson_3",
    title: "How to Master One-Tap Accuracy",
    category: "weapons",
    difficulty: "Advanced",
    duration: "20 mins",
    isPremium: false,
    summary: "The definitive guide to landing single-bullet kills with Desert Eagle, M1887, Woodpecker, and AC80.",
    instructions: [
      "1. The Jump-Shot Timing: Jump, wait until your character's feet are about to touch the ground (terminal velocity moment), then flick the fire button.",
      "2. The Lock-and-Release: Tap fire button once, immediately switch to Gloo Wall or melee fist, and sprint.",
      "3. Desert Eagle Sweet Spot: Place crosshair slightly to the left/bottom of the enemy's neck before dragging up.",
      "4. Woodpecker Tap Cadence: Never spray. Tap once every 0.6 seconds to let weapon recoil reset to 0."
    ],
    exercises: [
      "Training Ground combat zone: Enter with only Desert Eagle. Achieve at least 15 one-tap eliminations.",
      "M1887 One-Tap + Gloo Wall drill: Shoot 1 shell, place instant crouch Gloo Wall, switch to fist."
    ]
  },
  {
    id: "lesson_4",
    title: "How to Control Recoil",
    category: "aiming",
    difficulty: "Beginner",
    duration: "12 mins",
    isPremium: false,
    summary: "Prevent bullet spread and maintain laser-like pinpoint accuracy with high-recoil weapons like AK47 and Bizon.",
    instructions: [
      "1. The 3-Bullet Burst Rule: Fire 3-4 bullets, let go of the fire button for 0.3s, then fire again.",
      "2. Crouch-Shot Reset: When firing an AR, tap the crouch button on the 3rd bullet to tighten spread by 40%.",
      "3. Weapon Attachments: Always prioritize Muzzle (reduces horizontal spread) and Foregrip (reduces vertical recoil).",
      "4. Character Combinations: Utilize D-Bee (+60% accuracy while moving) or Laura (+50% accuracy while scoped in)."
    ],
    exercises: [
      "Training Room: Pick up an AK47 with NO attachments. Shoot target at 20 meters, keeping all 30 bullets within the red bullseye."
    ]
  },
  {
    id: "lesson_5",
    title: "How to Improve Movement",
    category: "movement",
    difficulty: "Intermediate",
    duration: "18 mins",
    isPremium: true,
    summary: "Master unpredictable zig-zag sprint, quick weapon switch slide, and high-speed evasive acrobatics.",
    instructions: [
      "1. Quick Weapon Switch: Enable the dedicated 'Quick Weapon Switch' button in settings. Never tap weapons in the top inventory.",
      "2. Zig-Zag Sprinting: Alternate flicking your joystick 45° left and 45° right every 0.8 seconds while camera flicking.",
      "3. Sliding Jump: Slide behind cover, jump sideways, and pre-aim your crosshair at head height where the rusher will emerge.",
      "4. Avoid Joystick Stagnation: Never hold the analog stick while firing; plant your feet, fire 2-3 bullets, and sprint."
    ],
    exercises: [
      "Movement Course: Navigate around gloo walls in training zone without getting hit by snipers."
    ]
  },
  {
    id: "lesson_6",
    title: "How to Master Close-Range Fights",
    category: "tactics",
    difficulty: "Advanced",
    duration: "25 mins",
    isPremium: true,
    summary: "Dominate 1v1 and 1v2 shotgun shotgun engagements with split-second Gloo Wall deployment and jump flicks.",
    instructions: [
      "1. Fast Crouch Gloo Wall: Shoot -> tap Gloo Wall -> tap Crouch -> tap Left Fire Button -> tap Sprint. Execute under 0.2s.",
      "2. The 360° Shield: When surrounded, hold Gloo Wall and spin your camera in a full circle while tapping fire button twice.",
      "3. Peekers Advantage: In close quarters, always swing out from the right side of cover (third-person camera sits on right shoulder).",
      "4. Baiting: Fake a reload step, listen for the opponent rushing, and pop out with a pre-charged M1014 or MP40 spray."
    ],
    exercises: [
      "Custom Room 1v1: Play with friends using only M1887 and unlimited gloo walls to practice 0.2s crouch placement."
    ]
  },
  {
    id: "lesson_7",
    title: "How to Master Long-Range Shooting",
    category: "aiming",
    difficulty: "Intermediate",
    duration: "15 mins",
    isPremium: true,
    summary: "Sniper mastery and 4X scope stability techniques to eliminate targets across 80+ meters.",
    instructions: [
      "1. Single-Tap Rhythm: When shooting with SVD, Woodpecker, or Marksman rifles, wait for the scope reticle to re-center.",
      "2. Anticipate Enemy Pathing: At long range, aim 1 body-width ahead of running targets.",
      "3. Double Sniper Switch (AWM / Barret M82B): Fire -> Quick Switch to 2nd Sniper -> Fire again without bolt reload animation.",
      "4. Vehicle Sniping: Aim for the driver's head window using M82B (anti-material rifle penetrates vehicles and gloo walls)."
    ],
    exercises: [
      "Target Range 50m+: Land 20 consecutive headshots with AWM without missing a shot."
    ]
  },
  {
    id: "lesson_8",
    title: "How to Master Different Weapons",
    category: "weapons",
    difficulty: "Intermediate",
    duration: "20 mins",
    isPremium: true,
    summary: "Comprehensive guide to all Free Fire weapon classes: Shotguns, SMGs, ARs, Marksman, and Snipers.",
    instructions: [
      "1. Shotguns (M1887, M1014, Charge Buster): Maximize high-speed drag; get within 7 meters for lethal pellet spread.",
      "2. SMGs (MP40, Thompson, UMP): UMP has armor penetration; aim for chest, slight drag snaps straight to head.",
      "3. Assault Rifles (AK, M4A1, SCAR): Mid-range beasts; burst fire in sets of 3; pair with 2X or 4X scopes.",
      "4. Marksman Rifles (Woodpecker, SVD): Highest damage-per-bullet; always aim for single-tap headshots.",
      "5. Snipers (AWM, Kar98k, M82B): Master non-reload quick switch and hold-to-scope firing."
    ],
    exercises: [
      "Gun Mastery Test: Win a training match scoring kills with at least 1 weapon from each of the 5 categories."
    ]
  },
  {
    id: "lesson_9",
    title: "How to Improve Reaction Time",
    category: "tactics",
    difficulty: "Beginner",
    duration: "10 mins",
    isPremium: true,
    summary: "Scientific exercises to lower your reaction speed from 300ms down to esports-level 180ms.",
    instructions: [
      "1. 5-Minute Finger Warm-up: Stretch wrists, flex fingers, tap thumb against index in rapid rhythm before opening the game.",
      "2. High-Refresh Device Settings: Ensure phone is set to 90Hz or 120Hz; turn on Game Turbo / Performance Mode.",
      "3. 3D Spatial Audio Cues: Use quality stereo earphones; train yourself to pinpoint enemy distance from footstep gravel/wood sound.",
      "4. Pre-Aiming Corners: Never look at blank walls; keep your crosshair glued to the door frame or corner where enemies peek."
    ],
    exercises: [
      "Reflex Drill: In training ground, react to random spawning bots; shoot within 0.25 seconds of visual detection."
    ]
  },
  {
    id: "lesson_10",
    title: "How to Develop Better Game Sense",
    category: "tactics",
    difficulty: "Advanced",
    duration: "22 mins",
    isPremium: true,
    summary: "Pro map awareness, zone rotations, third-party timing, and high-ground macro strategy.",
    instructions: [
      "1. Safe Zone Rotation: Rotate on the thin side of the gas circle (zone edge) to eliminate enemies fleeing the storm.",
      "2. The Third-Party Rule: When hearing two teams fighting, wait until you see 2 knockdowns in the killfeed, then rush the survivors.",
      "3. High Ground Advantage: Always secure hills, rooftops, or towers; high ground grants an extra 20% headshot angle view.",
      "4. Information Gathering: Use scan UAVs, character skills (Moco tag, Clu tracking, Homer drone) to dictate engagement terms."
    ],
    exercises: [
      "Play 3 BR matches focusing solely on positioning: achieve Top 3 placement in all 3 without taking early 50/50 fights."
    ]
  },
  {
    id: "lesson_11",
    title: "How to Improve Movement in Clash Squad",
    category: "modes",
    difficulty: "Intermediate",
    duration: "15 mins",
    isPremium: true,
    summary: "Clash Squad meta strategies: round 1 coin economy, rush paths, and coordinated crossfires.",
    instructions: [
      "1. Round 1 Economy: Buy G18 or Katana; preserve maximum gold for Round 2 Thomson / Desert Eagle purchase.",
      "2. Coordinated Rush: Never rush alone; always push in pairs so your partner can immediately re-frag if you get knocked.",
      "3. Grenade Bouncing: Cook grenades for 2.5 seconds before throwing through second-story windows into enemy sniper nests.",
      "4. Mushroom Buff Priority: Always purchase Level 3 Mushroom for continuous EP-to-HP regeneration in shootouts."
    ],
    exercises: [
      "Achieve 5 consecutive Clash Squad ranked victories applying the 2-man buddy rush system."
    ]
  },
  {
    id: "lesson_12",
    title: "How to Become Better in Battle Royale",
    category: "modes",
    difficulty: "Advanced",
    duration: "25 mins",
    isPremium: true,
    summary: "From landing to Booyah: hot drop survival, loadout optimization, airdrop control, and final circle endgame.",
    instructions: [
      "1. Hot Drop vs Cold Drop: If playing ranked points, land 200m away from central hotspots (Peak, Clock Tower, Bimasakti Strip).",
      "2. Loadout Synergy: Equip Armor Crate + Scan or Bonfire + Bounty Token for early game edge.",
      "3. Final Circle Gloo Bunker: In the final 10-meter circle, construct a 3-Gloo triangle fort; hold grenades to flush out prone campers.",
      "4. Character Combos: Meta combination: Tatsuya (Double dash) + Kelly (Sprint) + Hayato (Armor penetration on low HP) + Moco."
    ],
    exercises: [
      "Ranked BR Challenge: Win 1 Solo-vs-Squad or Squad match scoring 8+ kills with Booyah."
    ]
  }
];

const DEFAULT_WEAPONS = [
  {
    name: "M1887",
    category: "Shotguns",
    damage: 100,
    rateOfFire: 40,
    range: 19,
    reloadSpeed: 55,
    magazine: 2,
    accuracy: 10,
    movementSpeed: 79,
    armorPen: 54,
    description: "The King of One-Tap close combat. Lethal double barrel with unmatched high burst damage."
  },
  {
    name: "MP40",
    category: "SMGs",
    damage: 48,
    rateOfFire: 83,
    range: 22,
    reloadSpeed: 48,
    magazine: 20,
    accuracy: 17,
    movementSpeed: 88,
    armorPen: 0,
    description: "Insane fire rate. Ideal for close to mid-range straight drag headshots."
  },
  {
    name: "Woodpecker",
    category: "Marksman",
    damage: 85,
    rateOfFire: 38,
    range: 63,
    reloadSpeed: 48,
    magazine: 12,
    accuracy: 69,
    movementSpeed: 62,
    armorPen: 75,
    description: "Extreme armor penetration. One headshot instantly knocks any helmet level."
  },
  {
    name: "Desert Eagle",
    category: "Pistols",
    damage: 90,
    rateOfFire: 33,
    range: 38,
    reloadSpeed: 69,
    magazine: 7,
    accuracy: 45,
    movementSpeed: 76,
    armorPen: 0,
    description: "The classic one-tap sidearm. Requires precise jump-drag timing for devastating headshots."
  },
  {
    name: "AWM",
    category: "Snipers",
    damage: 90,
    rateOfFire: 27,
    range: 91,
    reloadSpeed: 34,
    magazine: 5,
    accuracy: 90,
    movementSpeed: 65,
    armorPen: 0,
    description: "Legendary long-range sniper rifle. High damage and pinpoint precision with built-in 8X scope."
  },
  {
    name: "SCAR",
    category: "Assault Rifles",
    damage: 54,
    rateOfFire: 61,
    range: 68,
    reloadSpeed: 52,
    magazine: 30,
    accuracy: 50,
    movementSpeed: 74,
    armorPen: 0,
    description: "Most balanced beginner-friendly AR. Predictable recoil and smooth 2X scope drag mechanics."
  },
  {
    name: "M1014",
    category: "Shotguns",
    damage: 94,
    rateOfFire: 38,
    range: 10,
    reloadSpeed: 20,
    magazine: 6,
    accuracy: 10,
    movementSpeed: 60,
    armorPen: 0,
    description: "Devastating pump action. Upgradeable with chip attachments to shred enemies in close quarters."
  },
  {
    name: "UMP",
    category: "SMGs",
    damage: 50,
    rateOfFire: 75,
    range: 25,
    reloadSpeed: 59,
    magazine: 30,
    accuracy: 42,
    movementSpeed: 79,
    armorPen: 63,
    description: "High armor penetration SMG. The preferred tournament gun for close-to-mid spray drags."
  }
];

class FreeFireDatabase {
  constructor() {
    this.storagePrefix = "ff_coach_";
    this.initLocalStore();
  }

  initLocalStore() {
    if (!this.get("app_settings")) {
      this.set("app_settings", DEFAULT_APP_SETTINGS);
    }
    if (!this.get("plans")) {
      this.set("plans", DEFAULT_PLANS);
    }
    if (!this.get("lessons")) {
      this.set("lessons", DEFAULT_LESSONS);
    }
    if (!this.get("weapons")) {
      this.set("weapons", DEFAULT_WEAPONS);
    }
    if (!this.get("users")) {
      // Seed initial admin and demo users
      const initialUsers = [
        {
          uid: "admin_master_001",
          email: "admin@freefirecoach.com",
          ign: "FFC_COMMANDER",
          ffUid: "9988776655",
          rank: "Grandmaster",
          role: "Rusher & Coach",
          avatar: "avatar_flame",
          plan: "lifetime",
          subscriptionStatus: "active",
          expiresAt: "2036-12-31T23:59:59.000Z",
          generationsCount: 154,
          completedLessons: ["lesson_1", "lesson_2", "lesson_3", "lesson_4", "lesson_5"],
          isAdmin: true,
          status: "active",
          createdAt: new Date().toISOString()
        },
        {
          uid: "demo_user_002",
          email: "player@freefirecoach.com",
          ign: "Shadow_Sniper",
          ffUid: "1234567890",
          rank: "Heroic",
          role: "Sniper",
          avatar: "avatar_sniper",
          plan: "free",
          subscriptionStatus: "inactive",
          expiresAt: null,
          generationsCount: 1,
          completedLessons: ["lesson_1"],
          isAdmin: false,
          status: "active",
          createdAt: new Date().toISOString()
        }
      ];
      this.set("users", initialUsers);
    }
    if (!this.get("payments")) {
      // Seed a realistic pending payment so Admin Dashboard can be tested immediately
      const initialPayments = [
        {
          id: "FFC-PAY-98124",
          userId: "demo_user_002",
          userEmail: "player@freefirecoach.com",
          userIgn: "Shadow_Sniper",
          planId: "monthly",
          planName: "Monthly Premium",
          amount: "₦8,500 ($7.99)",
          currency: "NGN",
          bankName: "Moniepoint MFB",
          accountNumber: "5174001034",
          senderName: "Babatunde Ade",
          sessionReference: "MNP-TRX-20261106-904123",
          receiptImage: "",
          status: "pending",
          submittedAt: new Date(Date.now() - 3600000).toISOString(),
          reviewedAt: null,
          adminNotes: ""
        }
      ];
      this.set("payments", initialPayments);
    }
    if (!this.get("sensitivity_profiles")) {
      this.set("sensitivity_profiles", []);
    }
    if (!this.get("notifications")) {
      this.set("notifications", [
        {
          id: "notif_welcome",
          userId: "all",
          title: "Welcome to FREE FIRE COACH! 🔥",
          message: "Generate your personalized sensitivity and start training your drag headshots today.",
          type: "announcement",
          createdAt: new Date().toISOString()
        }
      ]);
    }
  }

  get(key) {
    try {
      const data = localStorage.getItem(this.storagePrefix + key);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      console.error("Storage read error:", e);
      return null;
    }
  }

  set(key, value) {
    try {
      localStorage.setItem(this.storagePrefix + key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error("Storage write error:", e);
      return false;
    }
  }

  // App Settings
  getAppSettings() {
    return this.get("app_settings") || DEFAULT_APP_SETTINGS;
  }

  updateAppSettings(newSettings) {
    const current = this.getAppSettings();
    const updated = { ...current, ...newSettings };
    this.set("app_settings", updated);
    return updated;
  }

  // Subscription Plans
  getPlans() {
    return this.get("plans") || DEFAULT_PLANS;
  }

  updatePlan(planId, updates) {
    const plans = this.getPlans();
    const index = plans.findIndex(p => p.id === planId);
    if (index !== -1) {
      plans[index] = { ...plans[index], ...updates };
      this.set("plans", plans);
      return plans[index];
    }
    return null;
  }

  // Users
  getUsers() {
    return this.get("users") || [];
  }

  getUser(uid) {
    const users = this.getUsers();
    return users.find(u => u.uid === uid) || null;
  }

  getUserByEmail(email) {
    const users = this.getUsers();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
  }

  saveUser(user) {
    const users = this.getUsers();
    const index = users.findIndex(u => u.uid === user.uid);
    if (index !== -1) {
      users[index] = { ...users[index], ...user };
    } else {
      users.push(user);
    }
    this.set("users", users);
    return user;
  }

  deleteUser(uid) {
    let users = this.getUsers();
    users = users.filter(u => u.uid !== uid);
    this.set("users", users);
    return true;
  }

  // Lessons
  getLessons() {
    return this.get("lessons") || DEFAULT_LESSONS;
  }

  saveLesson(lesson) {
    const lessons = this.getLessons();
    const index = lessons.findIndex(l => l.id === lesson.id);
    if (index !== -1) {
      lessons[index] = { ...lessons[index], ...lesson };
    } else {
      lesson.id = lesson.id || "lesson_" + Date.now();
      lessons.push(lesson);
    }
    this.set("lessons", lessons);
    return lesson;
  }

  deleteLesson(lessonId) {
    let lessons = this.getLessons();
    lessons = lessons.filter(l => l.id !== lessonId);
    this.set("lessons", lessons);
    return true;
  }

  // Weapons
  getWeapons() {
    return this.get("weapons") || DEFAULT_WEAPONS;
  }

  // Payments
  getPayments() {
    return this.get("payments") || [];
  }

  getPayment(paymentId) {
    const payments = this.getPayments();
    return payments.find(p => p.id === paymentId) || null;
  }

  savePayment(payment) {
    const payments = this.getPayments();
    const index = payments.findIndex(p => p.id === payment.id);
    if (index !== -1) {
      payments[index] = { ...payments[index], ...payment };
    } else {
      payments.unshift(payment);
    }
    this.set("payments", payments);
    return payment;
  }

  // Sensitivity Profiles
  getSensitivityProfiles(userId) {
    const all = this.get("sensitivity_profiles") || [];
    if (!userId) return all;
    return all.filter(p => p.userId === userId);
  }

  saveSensitivityProfile(profile) {
    const all = this.get("sensitivity_profiles") || [];
    const index = all.findIndex(p => p.id === profile.id);
    if (index !== -1) {
      all[index] = { ...all[index], ...profile };
    } else {
      profile.id = profile.id || "sens_" + Date.now();
      profile.createdAt = profile.createdAt || new Date().toISOString();
      all.unshift(profile);
    }
    this.set("sensitivity_profiles", all);
    return profile;
  }

  deleteSensitivityProfile(profileId) {
    let all = this.get("sensitivity_profiles") || [];
    all = all.filter(p => p.id !== profileId);
    this.set("sensitivity_profiles", all);
    return true;
  }

  // Notifications
  getNotifications(userId) {
    const all = this.get("notifications") || [];
    return all.filter(n => n.userId === "all" || n.userId === userId);
  }

  sendNotification(notif) {
    const all = this.get("notifications") || [];
    notif.id = notif.id || "notif_" + Date.now();
    notif.createdAt = notif.createdAt || new Date().toISOString();
    all.unshift(notif);
    this.set("notifications", all);
    return notif;
  }
}

// Global database instance
const FF_DB = new FreeFireDatabase();
window.FF_DB = FF_DB;
