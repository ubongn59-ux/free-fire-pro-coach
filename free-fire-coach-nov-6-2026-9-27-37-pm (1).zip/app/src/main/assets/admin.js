/**
 * FREE FIRE COACH - Admin Portal Controller
 */

document.addEventListener("DOMContentLoaded", () => {
  initAdmin();
});

let currentPaymentFilter = "all";
let currentReceiptModalImg = "";

function initAdmin() {
  checkAdminAccess();
  setupAdminNavigation();
  setupAdminForms();
  renderAdminOverview();
  renderUsersTable();
  renderPaymentsTable();
  renderPlansManagement();
  renderLessonsManagement();
  renderBankSettings();
}

function checkAdminAccess() {
  const isAuthorized = window.FF_AUTH.isAdmin();
  const guard = document.getElementById("admin-auth-guard");
  const panel = document.getElementById("admin-main-panel");

  if (!isAuthorized) {
    if (guard) guard.style.display = "block";
    if (panel) panel.style.display = "none";
  } else {
    if (guard) guard.style.display = "none";
    if (panel) panel.style.display = "block";
  }
}

function adminLoginSubmit(e) {
  e.preventDefault();
  const email = document.getElementById("admin-login-email").value;
  const pass = document.getElementById("admin-login-pass").value;

  window.FF_AUTH.login(email, pass).then((user) => {
    if (user.isAdmin || user.email === "admin@freefirecoach.com") {
      showAdminToast("Admin Authorized! Welcome back.");
      checkAdminAccess();
      renderAdminOverview();
      renderUsersTable();
      renderPaymentsTable();
    } else {
      showAdminToast("Account is not authorized as an administrator.", false);
    }
  }).catch((err) => {
    showAdminToast(err.message, false);
  });
}

function setupAdminNavigation() {
  const tabs = document.querySelectorAll(".admin-tab-btn");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");

      const target = tab.getAttribute("data-tab");
      document.querySelectorAll(".admin-tab-content").forEach(c => c.style.display = "none");
      const targetContent = document.getElementById("tab-" + target);
      if (targetContent) targetContent.style.display = "block";
    });
  });

  // Search Users
  const userSearch = document.getElementById("admin-search-users");
  if (userSearch) {
    userSearch.addEventListener("input", renderUsersTable);
  }

  // Payment Filter tabs
  const payFilterBtns = document.querySelectorAll(".pay-filter-btn");
  payFilterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      payFilterBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentPaymentFilter = btn.getAttribute("data-filter");
      renderPaymentsTable();
    });
  });
}

function setupAdminForms() {
  // Plan Edit Form
  const formPlan = document.getElementById("admin-form-plans");
  if (formPlan) {
    formPlan.addEventListener("submit", (e) => {
      e.preventDefault();
      savePlanSettings();
    });
  }

  // Bank Transfer Settings Form
  const formBank = document.getElementById("admin-form-bank");
  if (formBank) {
    formBank.addEventListener("submit", (e) => {
      e.preventDefault();
      saveBankSettings();
    });
  }

  // Announcement Broadcast Form
  const formBroadcast = document.getElementById("admin-form-broadcast");
  if (formBroadcast) {
    formBroadcast.addEventListener("submit", (e) => {
      e.preventDefault();
      broadcastNotification();
    });
  }

  // Add Lesson Form
  const formLesson = document.getElementById("admin-form-add-lesson");
  if (formLesson) {
    formLesson.addEventListener("submit", (e) => {
      e.preventDefault();
      saveNewLesson();
    });
  }
}

/* ==========================================================================
   Admin Overview
   ========================================================================== */
function renderAdminOverview() {
  const users = window.FF_DB.getUsers();
  const payments = window.FF_DB.getPayments();

  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.status !== "suspended").length;
  const vipUsers = users.filter(u => {
    if (u.isAdmin) return true;
    if (u.subscriptionStatus === "active") {
      if (!u.expiresAt) return true;
      return new Date(u.expiresAt).getTime() > Date.now();
    }
    return false;
  }).length;

  const pendingPayments = payments.filter(p => p.status === "pending").length;
  const approvedPayments = payments.filter(p => p.status === "approved").length;
  const rejectedPayments = payments.filter(p => p.status === "rejected").length;

  // Approximate revenue calculation
  const totalRevenueNGN = approvedPayments * 8500; // estimated avg

  document.getElementById("stat-total-users").textContent = totalUsers;
  document.getElementById("stat-vip-users").textContent = vipUsers;
  document.getElementById("stat-pending-payments").textContent = pendingPayments;
  document.getElementById("stat-approved-payments").textContent = approvedPayments;
  document.getElementById("stat-total-revenue").textContent = `₦${totalRevenueNGN.toLocaleString()}`;
}

/* ==========================================================================
   User Management
   ========================================================================== */
function renderUsersTable() {
  const tbody = document.getElementById("admin-users-table-body");
  if (!tbody) return;

  const users = window.FF_DB.getUsers();
  const search = (document.getElementById("admin-search-users")?.value || "").toLowerCase();

  const filtered = users.filter(u => 
    (u.ign && u.ign.toLowerCase().includes(search)) ||
    (u.email && u.email.toLowerCase().includes(search)) ||
    (u.ffUid && u.ffUid.includes(search))
  );

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 24px;">No users found.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(u => {
    const isVip = u.subscriptionStatus === "active" || u.isAdmin;
    const isSuspended = u.status === "suspended";

    return `
      <tr>
        <td>
          <strong style="color: #FFF;">${escapeHtml(u.ign || "Player")}</strong>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(u.email)}</div>
        </td>
        <td>${escapeHtml(u.ffUid || "N/A")}</td>
        <td><span style="font-size: 0.75rem; font-weight: 700;">${escapeHtml(u.rank || "Heroic")}</span></td>
        <td>
          <span class="${isVip ? 'badge-status-approved' : 'badge-status-rejected'}">
            ${u.isAdmin ? '👑 ADMIN' : (isVip ? 'VIP ' + (u.plan || '').toUpperCase() : 'FREE')}
          </span>
        </td>
        <td>${u.generationsCount || 0}</td>
        <td>
          <span style="color: ${isSuspended ? 'var(--ff-red)' : 'var(--ff-green)'}; font-weight: 700; font-size: 0.8rem;">
            ${isSuspended ? 'Suspended' : 'Active'}
          </span>
        </td>
        <td>
          <div style="display: flex; gap: 6px;">
            <button class="btn btn-secondary btn-sm" onclick="promptGrantVip('${u.uid}')">
              ${isVip ? 'Edit VIP' : 'Grant VIP'}
            </button>
            <button class="btn btn-secondary btn-sm" onclick="toggleUserSuspension('${u.uid}')">
              ${isSuspended ? 'Reactivate' : 'Suspend'}
            </button>
            <button class="btn btn-secondary btn-sm" style="color: var(--ff-red);" onclick="deleteUserHandler('${u.uid}')">
              🗑️
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join("");
}

function promptGrantVip(userId) {
  const user = window.FF_DB.getUser(userId);
  if (!user) return;

  const planChoice = prompt(`Grant VIP to ${user.ign}?\nEnter plan: 'weekly', 'monthly', 'lifetime', or 'none' to revoke:`, user.plan || "monthly");
  if (!planChoice) return;

  const choice = planChoice.trim().toLowerCase();
  if (choice === "none") {
    user.subscriptionStatus = "inactive";
    user.plan = "free";
    user.expiresAt = null;
    window.FF_DB.saveUser(user);
    showAdminToast(`VIP access revoked for ${user.ign}`);
  } else if (["weekly", "monthly", "lifetime"].includes(choice)) {
    user.subscriptionStatus = "active";
    user.plan = choice;
    const days = choice === "weekly" ? 7 : (choice === "monthly" ? 30 : 3650);
    user.expiresAt = new Date(Date.now() + days * 86400000).toISOString();
    window.FF_DB.saveUser(user);

    window.FF_DB.sendNotification({
      userId: user.uid,
      title: "👑 Premium VIP Activated by Admin",
      message: `Your account has been upgraded to ${choice.toUpperCase()} VIP access. Enjoy all masterclasses and unlimited sensitivity!`,
      type: "system"
    });

    showAdminToast(`Granted ${choice.toUpperCase()} VIP to ${user.ign}!`);
  } else {
    showAdminToast("Invalid plan choice.", false);
  }

  renderUsersTable();
  renderAdminOverview();
}

function toggleUserSuspension(userId) {
  const user = window.FF_DB.getUser(userId);
  if (!user) return;
  if (user.isAdmin) {
    showAdminToast("Cannot suspend primary administrator.", false);
    return;
  }

  user.status = user.status === "suspended" ? "active" : "suspended";
  window.FF_DB.saveUser(user);
  showAdminToast(`User status updated to: ${user.status}`);
  renderUsersTable();
  renderAdminOverview();
}

function deleteUserHandler(userId) {
  const user = window.FF_DB.getUser(userId);
  if (!user) return;
  if (user.isAdmin) {
    showAdminToast("Cannot delete primary administrator.", false);
    return;
  }

  if (confirm(`Are you sure you want to delete user ${user.ign} (${user.email})?`)) {
    window.FF_DB.deleteUser(userId);
    showAdminToast("User deleted permanently.");
    renderUsersTable();
    renderAdminOverview();
  }
}

/* ==========================================================================
   Payment Management & Manual Approval / Rejection
   ========================================================================== */
function renderPaymentsTable() {
  const tbody = document.getElementById("admin-payments-table-body");
  if (!tbody) return;

  const payments = window.FF_DB.getPayments();
  const filtered = payments.filter(p => {
    if (currentPaymentFilter === "all") return true;
    return p.status === currentPaymentFilter;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 24px;">No payments matching filter '${currentPaymentFilter}'.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(p => {
    let statusClass = "badge-status-pending";
    if (p.status === "approved") statusClass = "badge-status-approved";
    if (p.status === "rejected") statusClass = "badge-status-rejected";

    return `
      <tr>
        <td><strong>${escapeHtml(p.id)}</strong></td>
        <td>
          <div style="font-weight: 700; color: #FFF;">${escapeHtml(p.userIgn || "User")}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(p.userEmail)}</div>
        </td>
        <td>
          <div>${escapeHtml(p.planName)}</div>
          <strong style="color: var(--ff-orange); font-size: 0.85rem;">${escapeHtml(p.amount)}</strong>
        </td>
        <td>
          <div style="font-family: monospace; font-size: 0.8rem; color: #FFF;">${escapeHtml(p.sessionReference)}</div>
          <div style="font-size: 0.72rem; color: var(--text-muted);">Sender: ${escapeHtml(p.senderName)}</div>
        </td>
        <td>
          ${p.receiptImage ? `
            <button class="btn btn-secondary btn-sm" onclick="viewReceiptImage('${p.id}')">
              🖼️ View Receipt
            </button>
          ` : '<span style="font-size: 0.75rem; color: var(--text-muted);">No receipt image</span>'}
        </td>
        <td><span class="${statusClass}">${p.status.toUpperCase()}</span></td>
        <td>
          ${p.status === "pending" ? `
            <div style="display: flex; gap: 6px;">
              <button class="btn btn-primary btn-sm" onclick="approvePayment('${p.id}')">
                ✅ Approve
              </button>
              <button class="btn btn-secondary btn-sm" style="color: var(--ff-red);" onclick="rejectPayment('${p.id}')">
                ❌ Reject
              </button>
            </div>
          ` : `
            <span style="font-size: 0.75rem; color: var(--text-muted);">
              Reviewed ${p.reviewedAt ? new Date(p.reviewedAt).toLocaleDateString() : ''}
            </span>
          `}
        </td>
      </tr>
    `;
  }).join("");
}

function viewReceiptImage(paymentId) {
  const payment = window.FF_DB.getPayment(paymentId);
  if (!payment || !payment.receiptImage) {
    showAdminToast("Receipt image not available.", false);
    return;
  }

  const modalImg = document.getElementById("admin-receipt-modal-img");
  const modalRef = document.getElementById("admin-receipt-modal-ref");
  if (modalImg) modalImg.src = payment.receiptImage;
  if (modalRef) modalRef.textContent = `Payment: ${payment.id} • Ref: ${payment.sessionReference}`;

  openAdminModal("modal-admin-receipt");
}

function approvePayment(paymentId) {
  const payment = window.FF_DB.getPayment(paymentId);
  if (!payment) return;

  payment.status = "approved";
  payment.reviewedAt = new Date().toISOString();
  payment.adminNotes = "Payment verified by administrator on Moniepoint MFB statement.";
  window.FF_DB.savePayment(payment);

  // Automatically activate the user's subscription
  const user = window.FF_DB.getUser(payment.userId);
  if (user) {
    user.subscriptionStatus = "active";
    user.plan = payment.planId || "monthly";

    const days = user.plan === "weekly" ? 7 : (user.plan === "monthly" ? 30 : 3650);
    user.expiresAt = new Date(Date.now() + days * 86400000).toISOString();
    window.FF_DB.saveUser(user);

    // Notify user
    window.FF_DB.sendNotification({
      userId: user.uid,
      title: "🎉 Moniepoint Payment Approved!",
      message: `Your payment of ${payment.amount} has been verified! Your ${payment.planName} subscription is now ACTIVE. Enjoy unlimited pro features!`,
      type: "payment"
    });
  }

  showAdminToast(`Payment ${payment.id} Approved! Subscription activated.`);
  renderPaymentsTable();
  renderAdminOverview();
}

function rejectPayment(paymentId) {
  const payment = window.FF_DB.getPayment(paymentId);
  if (!payment) return;

  const reason = prompt("Enter rejection reason for this payment (e.g. 'Session ID not found on statement' or 'Incomplete amount'):", "Transaction not confirmed on bank statement.");
  if (!reason) return;

  payment.status = "rejected";
  payment.reviewedAt = new Date().toISOString();
  payment.adminNotes = reason;
  window.FF_DB.savePayment(payment);

  // Notify user
  const user = window.FF_DB.getUser(payment.userId);
  if (user) {
    window.FF_DB.sendNotification({
      userId: user.uid,
      title: "⚠️ Moniepoint Payment Verification Notice",
      message: `Your payment reference ${payment.id} could not be confirmed: ${reason}. Please contact support or re-submit with a valid receipt.`,
      type: "payment"
    });
  }

  showAdminToast(`Payment ${payment.id} marked as Rejected.`);
  renderPaymentsTable();
  renderAdminOverview();
}

/* ==========================================================================
   Subscription & Banking Settings
   ========================================================================== */
function renderPlansManagement() {
  const plans = window.FF_DB.getPlans();
  const weekly = plans.find(p => p.id === "weekly");
  const monthly = plans.find(p => p.id === "monthly");
  const lifetime = plans.find(p => p.id === "lifetime");

  if (weekly) {
    document.getElementById("plan-weekly-ngn").value = weekly.priceNGN;
    document.getElementById("plan-weekly-usd").value = weekly.priceUSD;
  }
  if (monthly) {
    document.getElementById("plan-monthly-ngn").value = monthly.priceNGN;
    document.getElementById("plan-monthly-usd").value = monthly.priceUSD;
  }
  if (lifetime) {
    document.getElementById("plan-lifetime-ngn").value = lifetime.priceNGN;
    document.getElementById("plan-lifetime-usd").value = lifetime.priceUSD;
  }
}

function savePlanSettings() {
  const weeklyNgn = parseFloat(document.getElementById("plan-weekly-ngn").value);
  const weeklyUsd = parseFloat(document.getElementById("plan-weekly-usd").value);
  const monthlyNgn = parseFloat(document.getElementById("plan-monthly-ngn").value);
  const monthlyUsd = parseFloat(document.getElementById("plan-monthly-usd").value);
  const lifetimeNgn = parseFloat(document.getElementById("plan-lifetime-ngn").value);
  const lifetimeUsd = parseFloat(document.getElementById("plan-lifetime-usd").value);

  window.FF_DB.updatePlan("weekly", { priceNGN: weeklyNgn, priceUSD: weeklyUsd });
  window.FF_DB.updatePlan("monthly", { priceNGN: monthlyNgn, priceUSD: monthlyUsd });
  window.FF_DB.updatePlan("lifetime", { priceNGN: lifetimeNgn, priceUSD: lifetimeUsd });

  showAdminToast("Subscription prices updated successfully!");
}

function renderBankSettings() {
  const settings = window.FF_DB.getAppSettings();
  document.getElementById("bank-setting-name").value = settings.bankName;
  document.getElementById("bank-setting-account-num").value = settings.accountNumber;
  document.getElementById("bank-setting-account-name").value = settings.accountName;
}

function saveBankSettings() {
  const bankName = document.getElementById("bank-setting-name").value.trim();
  const accountNumber = document.getElementById("bank-setting-account-num").value.trim();
  const accountName = document.getElementById("bank-setting-account-name").value.trim();

  window.FF_DB.updateAppSettings({ bankName, accountNumber, accountName });
  showAdminToast("Moniepoint bank transfer details updated!");
}

/* ==========================================================================
   Content & Lesson Management
   ========================================================================== */
function renderLessonsManagement() {
  const container = document.getElementById("admin-lessons-list");
  if (!container) return;

  const lessons = window.FF_DB.getLessons();
  container.innerHTML = lessons.map(l => `
    <div class="card" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; gap: 10px; flex-wrap: wrap;">
      <div>
        <h4 style="font-size: 1rem; color: #FFF; font-weight: 800;">${escapeHtml(l.title)}</h4>
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 2px;">
          ${l.category.toUpperCase()} • ${l.difficulty} • ${l.duration} • ${l.isPremium ? '👑 VIP' : 'FREE'}
        </div>
      </div>
      <div>
        <button class="btn btn-secondary btn-sm" style="color: var(--ff-red);" onclick="deleteLessonAdmin('${l.id}')">
          Delete Lesson
        </button>
      </div>
    </div>
  `).join("");
}

function saveNewLesson() {
  const title = document.getElementById("lesson-new-title").value.trim();
  const category = document.getElementById("lesson-new-cat").value;
  const difficulty = document.getElementById("lesson-new-diff").value;
  const duration = document.getElementById("lesson-new-duration").value.trim() || "15 mins";
  const summary = document.getElementById("lesson-new-summary").value.trim();
  const instructionsText = document.getElementById("lesson-new-inst").value.trim();
  const exercisesText = document.getElementById("lesson-new-ex").value.trim();
  const isPremium = document.getElementById("lesson-new-isvip").checked;

  if (!title || !summary) {
    showAdminToast("Please provide lesson title and summary.", false);
    return;
  }

  const newLesson = {
    id: "lesson_" + Date.now(),
    title: title,
    category: category,
    difficulty: difficulty,
    duration: duration,
    isPremium: isPremium,
    summary: summary,
    instructions: instructionsText.split("\n").filter(line => line.trim().length > 0),
    exercises: exercisesText.split("\n").filter(line => line.trim().length > 0)
  };

  window.FF_DB.saveLesson(newLesson);
  showAdminToast("New gameplay lesson published!");
  document.getElementById("admin-form-add-lesson").reset();
  renderLessonsManagement();
}

function deleteLessonAdmin(lessonId) {
  if (confirm("Delete this lesson from academy?")) {
    window.FF_DB.deleteLesson(lessonId);
    showAdminToast("Lesson removed.");
    renderLessonsManagement();
  }
}

/* ==========================================================================
   Announcements & Broadcasts
   ========================================================================== */
function broadcastNotification() {
  const title = document.getElementById("broadcast-title").value.trim();
  const message = document.getElementById("broadcast-message").value.trim();

  if (!title || !message) {
    showAdminToast("Please fill in both title and message.", false);
    return;
  }

  window.FF_DB.sendNotification({
    userId: "all",
    title: title,
    message: message,
    type: "announcement"
  });

  showAdminToast("Announcement broadcast to all players! 📢");
  document.getElementById("admin-form-broadcast").reset();
}

/* ==========================================================================
   Admin Modal & Toast Helpers
   ========================================================================== */
function openAdminModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add("active");
}

function closeAdminModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove("active");
}

function showAdminToast(msg, isSuccess = true) {
  let container = document.getElementById("admin-toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "admin-toast-container";
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<span>${isSuccess ? "⚡" : "⚠️"}</span> <span>${msg}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

window.adminLoginSubmit = adminLoginSubmit;
window.promptGrantVip = promptGrantVip;
window.toggleUserSuspension = toggleUserSuspension;
window.deleteUserHandler = deleteUserHandler;
window.approvePayment = approvePayment;
window.rejectPayment = rejectPayment;
window.viewReceiptImage = viewReceiptImage;
window.deleteLessonAdmin = deleteLessonAdmin;
window.openAdminModal = openAdminModal;
window.closeAdminModal = closeAdminModal;
