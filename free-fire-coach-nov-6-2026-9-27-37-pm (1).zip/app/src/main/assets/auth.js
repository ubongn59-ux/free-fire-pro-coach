/**
 * FREE FIRE COACH - Authentication & User State Management
 */

class FreeFireAuth {
  constructor() {
    this.currentUserIdKey = "ff_current_user_id";
    this.listeners = [];
    this.currentUser = this.loadSession();
  }

  loadSession() {
    const uid = localStorage.getItem(this.currentUserIdKey);
    if (!uid) {
      // Default to the demo player session if first launch, so the user can immediately experience the app!
      const demoUser = window.FF_DB ? window.FF_DB.getUser("demo_user_002") : null;
      if (demoUser) {
        localStorage.setItem(this.currentUserIdKey, demoUser.uid);
        return demoUser;
      }
      return null;
    }
    return window.FF_DB ? window.FF_DB.getUser(uid) : null;
  }

  getCurrentUser() {
    // Refresh user data from database to capture real-time subscription approvals
    if (this.currentUser && window.FF_DB) {
      const refreshed = window.FF_DB.getUser(this.currentUser.uid);
      if (refreshed) {
        this.currentUser = refreshed;
      }
    }
    return this.currentUser;
  }

  isLoggedIn() {
    return !!this.getCurrentUser();
  }

  isAdmin() {
    const user = this.getCurrentUser();
    return !!(user && (user.isAdmin || user.email === "admin@freefirecoach.com"));
  }

  isPremium() {
    const user = this.getCurrentUser();
    if (!user) return false;
    if (user.isAdmin) return true;
    if (user.subscriptionStatus === "active") {
      if (user.expiresAt) {
        const expiry = new Date(user.expiresAt);
        return expiry.getTime() > Date.now();
      }
      return true;
    }
    return false;
  }

  async signUp(email, password, ign, ffUid, rank = "Platinum", role = "Rusher", avatar = "avatar_flame") {
    if (!email || !password || !ign) {
      throw new Error("Please fill in email, password, and in-game name.");
    }
    if (password.length < 6) {
      throw new Error("Password must be at least 6 characters.");
    }

    const existing = window.FF_DB.getUserByEmail(email);
    if (existing) {
      throw new Error("An account with this email already exists.");
    }

    const newUser = {
      uid: "user_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
      email: email.trim().toLowerCase(),
      password: password, // In production Firestore, Firebase Auth handles password hashing
      ign: ign.trim(),
      ffUid: ffUid ? ffUid.trim() : "10" + Math.floor(10000000 + Math.random() * 90000000),
      rank: rank,
      role: role,
      avatar: avatar,
      plan: "free",
      subscriptionStatus: "inactive",
      expiresAt: null,
      generationsCount: 0,
      generationsToday: 0,
      lastGenDate: new Date().toDateString(),
      completedLessons: [],
      isAdmin: email.trim().toLowerCase() === "admin@freefirecoach.com",
      status: "active",
      createdAt: new Date().toISOString()
    };

    window.FF_DB.saveUser(newUser);
    this.setSession(newUser);

    // Welcome notification
    window.FF_DB.sendNotification({
      userId: newUser.uid,
      title: "Welcome to Free Fire Coach!",
      message: `Greetings ${newUser.ign}! Your training account is now active. Try the Sensitivity Generator now!`,
      type: "system"
    });

    return newUser;
  }

  async login(email, password) {
    if (!email || !password) {
      throw new Error("Please enter both email and password.");
    }

    const normalizedEmail = email.trim().toLowerCase();

    // Check special default admin credentials
    if (normalizedEmail === "admin@freefirecoach.com" && (password === "admin123" || password === "admin")) {
      let adminUser = window.FF_DB.getUser("admin_master_001");
      if (!adminUser) {
        adminUser = {
          uid: "admin_master_001",
          email: "admin@freefirecoach.com",
          ign: "FFC_COMMANDER",
          ffUid: "9988776655",
          rank: "Grandmaster",
          role: "Rusher & Coach",
          avatar: "avatar_flame",
          plan: "lifetime",
          subscriptionStatus: "active",
          expiresAt: "2036-12-31T23:59:59.000Z",
          generationsCount: 154,
          completedLessons: ["lesson_1", "lesson_2", "lesson_3", "lesson_4", "lesson_5"],
          isAdmin: true,
          status: "active",
          createdAt: new Date().toISOString()
        };
        window.FF_DB.saveUser(adminUser);
      }
      this.setSession(adminUser);
      return adminUser;
    }

    const user = window.FF_DB.getUserByEmail(normalizedEmail);
    if (!user) {
      throw new Error("No user found with this email. Please check your credentials or sign up.");
    }

    if (user.status === "suspended") {
      throw new Error("This account has been temporarily suspended. Please contact support.");
    }

    if (user.password && user.password !== password) {
      throw new Error("Incorrect password. Please try again.");
    }

    this.setSession(user);
    return user;
  }

  logout() {
    localStorage.removeItem(this.currentUserIdKey);
    this.currentUser = null;
    this.notifyListeners();
  }

  setSession(user) {
    this.currentUser = user;
    localStorage.setItem(this.currentUserIdKey, user.uid);
    this.notifyListeners();
  }

  updateProfile(updates) {
    if (!this.currentUser) return null;
    const updated = { ...this.currentUser, ...updates };
    window.FF_DB.saveUser(updated);
    this.currentUser = updated;
    this.notifyListeners();
    return updated;
  }

  canGenerateSensitivity() {
    if (this.isPremium()) return { allowed: true, remaining: "Unlimited" };

    const user = this.getCurrentUser();
    if (!user) return { allowed: true, remaining: 3 };

    const today = new Date().toDateString();
    if (user.lastGenDate !== today) {
      user.generationsToday = 0;
      user.lastGenDate = today;
      window.FF_DB.saveUser(user);
    }

    const limit = 3;
    const remaining = Math.max(0, limit - (user.generationsToday || 0));
    return {
      allowed: remaining > 0,
      remaining: remaining,
      limit: limit
    };
  }

  recordSensitivityGeneration() {
    const user = this.getCurrentUser();
    if (!user) return;
    const today = new Date().toDateString();
    if (user.lastGenDate !== today) {
      user.generationsToday = 0;
      user.lastGenDate = today;
    }
    user.generationsToday = (user.generationsToday || 0) + 1;
    user.generationsCount = (user.generationsCount || 0) + 1;
    window.FF_DB.saveUser(user);
    this.currentUser = user;
  }

  toggleLessonComplete(lessonId) {
    const user = this.getCurrentUser();
    if (!user) return false;

    user.completedLessons = user.completedLessons || [];
    const index = user.completedLessons.indexOf(lessonId);
    let completed = false;

    if (index === -1) {
      user.completedLessons.push(lessonId);
      completed = true;
    } else {
      user.completedLessons.splice(index, 1);
      completed = false;
    }

    window.FF_DB.saveUser(user);
    this.currentUser = user;
    this.notifyListeners();
    return completed;
  }

  onAuthStateChanged(callback) {
    this.listeners.push(callback);
    callback(this.getCurrentUser());
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  notifyListeners() {
    const user = this.getCurrentUser();
    this.listeners.forEach(cb => {
      try {
        cb(user);
      } catch (e) {
        console.error("Auth listener error:", e);
      }
    });
  }
}

// Global Auth Instance
const FF_AUTH = new FreeFireAuth();
window.FF_AUTH = FF_AUTH;
