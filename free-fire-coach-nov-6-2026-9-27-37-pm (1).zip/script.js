/**
 * FREE FIRE COACH - Core Frontend Controller
 */

document.addEventListener("DOMContentLoaded", () => {
  initApp();
});

let currentGeneratedSens = null;
let activeLessonFilter = "all";
let uploadedReceiptData = "";

function initApp() {
  setupNavigation();
  setupAuthUI();
  setupSensitivityGenerator();
  setupAcademy();
  setupWeapons();
  setupPricingAndPayments();
  setupDashboard();
  setupNotificationChecker();

  window.FF_AUTH.onAuthStateChanged((user) => {
    updateHeaderUserUI(user);
    renderDashboard();
    renderAcademyLessons();
    renderPricingPlans();
  });

  const params = new URLSearchParams(window.location.search);
  const targetView = params.get("view") || "home";
  switchView(targetView);
}

function setupNavigation() {
  const navItems = document.querySelectorAll("[data-nav-target]");
  navItems.forEach(item => {
    item.addEventListener("click", (e) => {
      e.preventDefault();
      const target = item.getAttribute("data-nav-target");
      switchView(target);
    });
  });
}

function switchView(viewId) {
  const sections = document.querySelectorAll(".view-section");
  sections.forEach(sec => sec.classList.remove("active"));

  const targetSection = document.getElementById("view-" + viewId);
  if (targetSection) {
    targetSection.classList.add("active");
  } else {
    document.getElementById("view-home")?.classList.add("active");
  }

  document.querySelectorAll("[data-nav-target]").forEach(nav => {
    if (nav.getAttribute("data-nav-target") === viewId) {
      nav.classList.add("active");
    } else {
      nav.classList.remove("active");
    }
  });

  window.scrollTo({ top: 0, behavior: "smooth" });

  if (viewId === "dashboard") {
    renderDashboard();
  } else if (viewId === "academy") {
    renderAcademyLessons();
  }
}

function showToast(message, isSuccess = true) {
  if (window.AndroidNative && window.AndroidNative.showToast) {
    window.AndroidNative.showToast(message);
  }

  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<span>${isSuccess ? "🔥" : "⚠️"}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

function copyText(text, label = "Settings") {
  if (window.AndroidNative && window.AndroidNative.copyToClipboard) {
    window.AndroidNative.copyToClipboard(text, label);
    return;
  }

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      showToast(`${label} copied to clipboard!`);
    }).catch(() => {
      fallbackCopy(text, label);
    });
  } else {
    fallbackCopy(text, label);
  }
}

function fallbackCopy(text, label) {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.position = "fixed";
  textArea.style.left = "-9999px";
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand("copy");
    showToast(`${label} copied!`);
  } catch (err) {
    prompt("Copy text manually:", text);
  }
  document.body.removeChild(textArea);
}

function updateHeaderUserUI(user) {
  const userBtn = document.getElementById("header-user-btn");
  const vipBadge = document.getElementById("header-vip-badge");
  const adminLink = document.getElementById("header-admin-link");

  if (!userBtn) return;

  if (user) {
    userBtn.innerHTML = `<span>👤</span> ${escapeHtml(user.ign || "Player")}`;
    userBtn.onclick = () => switchView("dashboard");

    if (vipBadge) {
      if (window.FF_AUTH.isPremium()) {
        vipBadge.className = "badge-vip";
        vipBadge.innerHTML = "👑 VIP PRO";
        vipBadge.style.display = "inline-flex";
      } else {
        vipBadge.className = "badge-free";
        vipBadge.innerHTML = "FREE TIER";
        vipBadge.style.display = "inline-flex";
      }
    }

    if (adminLink) {
      adminLink.style.display = (user.isAdmin || user.email === "admin@freefirecoach.com") ? "inline-flex" : "none";
    }
  } else {
    userBtn.innerHTML = `<span>⚡</span> Login`;
    userBtn.onclick = () => openModal("modal-auth-login");
    if (vipBadge) vipBadge.style.display = "none";
    if (adminLink) adminLink.style.display = "none";
  }
}

function setupSensitivityGenerator() {
  const form = document.getElementById("sens-generator-form");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    generateSensitivityHandler();
  });

  const btnCopy = document.getElementById("btn-copy-sens");
  if (btnCopy) {
    btnCopy.addEventListener("click", () => {
      if (!currentGeneratedSens) return;
      const text = `🔥 FREE FIRE COACH PRO SENSITIVITY 🔥
Device: ${currentGeneratedSens.device}
General: ${currentGeneratedSens.general}
Red Dot: ${currentGeneratedSens.redDot}
2X Scope: ${currentGeneratedSens.scope2x}
4X Scope: ${currentGeneratedSens.scope4x}
Sniper Scope: ${currentGeneratedSens.sniperScope}
Free Look: ${currentGeneratedSens.freeLook}
DPI: ${currentGeneratedSens.dpi}
Fire Button: ${currentGeneratedSens.fireButtonSize}%
Tuning: ${currentGeneratedSens.aimTips}`;
      copyText(text, "Sensitivity Settings");
    });
  }

  const btnSave = document.getElementById("btn-save-sens");
  if (btnSave) {
    btnSave.addEventListener("click", () => {
      if (!currentGeneratedSens) return;
      const user = window.FF_AUTH.getCurrentUser();
      if (!user) {
        showToast("Please log in to save settings!", false);
        openModal("modal-auth-login");
        return;
      }

      const profile = {
        userId: user.uid,
        name: `${currentGeneratedSens.device} - ${currentGeneratedSens.weapon}`,
        ...currentGeneratedSens
      };

      window.FF_DB.saveSensitivityProfile(profile);
      showToast("Saved to your profile!");
      renderDashboard();
    });
  }
}

function generateSensitivityHandler() {
  const status = window.FF_AUTH.canGenerateSensitivity();
  if (!status.allowed) {
    openModal("modal-upgrade-prompt");
    return;
  }

  const brand = document.getElementById("gen-brand").value;
  const model = document.getElementById("gen-model").value || "Custom Phone";
  const ram = parseInt(document.getElementById("gen-ram").value, 10) || 4;
  const refreshRate = parseInt(document.getElementById("gen-hz").value, 10) || 60;
  const fingers = parseInt(document.getElementById("gen-fingers").value, 10) || 2;
  const style = document.getElementById("gen-style").value;
  const weapon = document.getElementById("gen-weapon").value;
  const currentSens = document.getElementById("gen-current-sens").value;
  const aimStyle = document.getElementById("gen-aim-style").value;

  let baseGeneral = 95;
  let baseRedDot = 92;
  let base2x = 88;
  let base4x = 82;
  let baseSniper = 65;
  let baseFreeLook = 75;
  let recommendedDpi = 411;
  let fireButtonSize = 48;
  let aimTips = "";

  if (refreshRate >= 120) {
    baseGeneral -= 3;
    baseRedDot -= 2;
    recommendedDpi = 450;
  } else if (refreshRate === 90) {
    baseGeneral -= 1;
    recommendedDpi = 425;
  } else {
    baseGeneral += 3;
    baseRedDot += 3;
    recommendedDpi = (ram <= 4) ? 480 : 440;
  }

  if (ram <= 3) {
    baseGeneral += 2;
    baseRedDot += 2;
  }

  if (fingers === 2) {
    fireButtonSize = 52;
    baseGeneral += 2;
  } else if (fingers === 3) {
    fireButtonSize = 46;
  } else {
    fireButtonSize = 42;
    baseGeneral -= 2;
    baseRedDot += 2;
  }

  if (weapon === "Shotguns") {
    baseRedDot = Math.min(100, baseRedDot + 6);
    baseGeneral = Math.min(100, baseGeneral + 3);
    fireButtonSize -= 2;
    aimTips = "Shotgun Rusher Setup: Start drag while crosshair is WHITE at waist level, flick upwards with J-shape motion.";
  } else if (weapon === "SMG") {
    baseRedDot = Math.min(100, baseRedDot + 4);
    base2x = Math.min(100, base2x + 3);
    aimTips = "SMG Drag Master: Spray in bursts of 4-5 bullets. Straight-up drag with continuous gentle thumb pressure.";
  } else if (weapon === "Snipers") {
    baseSniper = Math.max(45, baseSniper - 12);
    baseGeneral = Math.max(88, baseGeneral - 3);
    aimTips = "Sniper Precision: Lower sniper sensitivity prevents scope jitter. Use quick weapon switch right after releasing fire.";
  } else if (weapon === "Desert Eagle") {
    baseRedDot = Math.min(100, baseRedDot + 5);
    baseGeneral = 99;
    aimTips = "One-Tap Pistol King: Jump shot cadence—drag at the exact moment of landing for 100% headshot connection.";
  } else {
    base2x = Math.min(96, base2x + 2);
    base4x = Math.min(94, base4x + 2);
    aimTips = "Assault Rifle Laser: Tap crouch on the 3rd bullet to eliminate bullet bloom and tighten headshot grouping.";
  }

  const clamp = (val) => Math.min(100, Math.max(30, Math.round(val)));

  currentGeneratedSens = {
    device: `${brand} ${model}`,
    ram: `${ram}GB RAM`,
    hz: `${refreshRate}Hz`,
    fingers: `${fingers}-Finger`,
    style: style,
    weapon: weapon,
    general: clamp(baseGeneral),
    redDot: clamp(baseRedDot),
    scope2x: clamp(base2x),
    scope4x: clamp(base4x),
    sniperScope: clamp(baseSniper),
    freeLook: clamp(baseFreeLook),
    dpi: recommendedDpi,
    fireButtonSize: fireButtonSize,
    aimTips: aimTips,
    hudGuide: `${fingers}-Finger HUD: Fire button at bottom right (15% from right edge, 20% from bottom). Quick weapon switch enabled on left screen.`
  };

  window.FF_AUTH.recordSensitivityGeneration();
  renderSensitivityResults(currentGeneratedSens);
  showToast("Sensitivity Generated Successfully!");
}

function renderSensitivityResults(sens) {
  const resultBox = document.getElementById("sens-result-container");
  if (!resultBox) return;

  resultBox.style.display = "block";
  resultBox.scrollIntoView({ behavior: "smooth", block: "start" });

  document.getElementById("res-device-name").textContent = sens.device;
  document.getElementById("res-device-specs").textContent = `${sens.ram} • ${sens.hz} • ${sens.fingers} • ${sens.weapon}`;

  setSensMeter("val-general", "bar-general", sens.general);
  setSensMeter("val-reddot", "bar-reddot", sens.redDot);
  setSensMeter("val-scope2x", "bar-scope2x", sens.scope2x);
  setSensMeter("val-scope4x", "bar-scope4x", sens.scope4x);
  setSensMeter("val-sniper", "bar-sniper", sens.sniperScope);
  setSensMeter("val-freelook", "bar-freelook", sens.freeLook);

  document.getElementById("res-dpi").textContent = sens.dpi;
  document.getElementById("res-fire-btn").textContent = sens.fireButtonSize + "%";
  document.getElementById("res-aim-tip").textContent = sens.aimTips;
  document.getElementById("res-hud-guide").textContent = sens.hudGuide;
}

function setSensMeter(valId, barId, value) {
  const valElem = document.getElementById(valId);
  const barElem = document.getElementById(barId);
  if (valElem) valElem.textContent = value;
  if (barElem) barElem.style.width = value + "%";
}

function setupAcademy() {
  const filterChips = document.querySelectorAll(".filter-chip[data-category]");
  filterChips.forEach(chip => {
    chip.addEventListener("click", () => {
      filterChips.forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      activeLessonFilter = chip.getAttribute("data-category");
      renderAcademyLessons();
    });
  });

  const searchInput = document.getElementById("academy-search-input");
  if (searchInput) {
    searchInput.addEventListener("input", () => {
      renderAcademyLessons();
    });
  }
}

function renderAcademyLessons() {
  const container = document.getElementById("academy-lessons-grid");
  if (!container) return;

  const lessons = window.FF_DB.getLessons();
  const user = window.FF_AUTH.getCurrentUser();
  const isVip = window.FF_AUTH.isPremium();
  const searchTerm = (document.getElementById("academy-search-input")?.value || "").toLowerCase();

  const filtered = lessons.filter(l => {
    const matchesCat = (activeLessonFilter === "all" || l.category === activeLessonFilter);
    const matchesSearch = l.title.toLowerCase().includes(searchTerm) || l.summary.toLowerCase().includes(searchTerm);
    return matchesCat && matchesSearch;
  });

  if (filtered.length === 0) {
    container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted);">No training lessons found matching your filter.</div>`;
    return;
  }

  container.innerHTML = filtered.map(lesson => {
    const isCompleted = user?.completedLessons?.includes(lesson.id);
    const isLocked = lesson.isPremium && !isVip;

    return `
      <div class="lesson-card" onclick="openLessonDetail('${lesson.id}')">
        <div>
          <div class="lesson-meta">
            <span class="difficulty-badge diff-${lesson.difficulty}">${lesson.difficulty}</span>
            <span class="lesson-duration">⏱️ ${lesson.duration}</span>
            ${lesson.isPremium ? '<span class="badge-vip" style="font-size: 0.65rem; padding: 2px 6px;">VIP MASTER</span>' : ''}
          </div>
          <h3 class="lesson-card-title">${escapeHtml(lesson.title)}</h3>
          <p class="lesson-card-desc">${escapeHtml(lesson.summary)}</p>
        </div>
        <div class="lesson-card-footer">
          <span class="lesson-status ${isCompleted ? 'status-completed' : 'status-pending'}">
            ${isCompleted ? '✅ Completed' : (isLocked ? '🔒 VIP Locked' : '📖 Start Lesson')}
          </span>
          <span style="color: var(--ff-orange); font-size: 0.85rem; font-weight: 700;">View Drill →</span>
        </div>
      </div>
    `;
  }).join("");
}

function openLessonDetail(lessonId) {
  const lesson = window.FF_DB.getLessons().find(l => l.id === lessonId);
  if (!lesson) return;

  const isVip = window.FF_AUTH.isPremium();
  if (lesson.isPremium && !isVip) {
    openModal("modal-upgrade-prompt");
    return;
  }

  const user = window.FF_AUTH.getCurrentUser();
  const isCompleted = user?.completedLessons?.includes(lesson.id);

  const modalBody = document.getElementById("lesson-modal-content");
  if (!modalBody) return;

  modalBody.innerHTML = `
    <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 12px;">
      <span class="difficulty-badge diff-${lesson.difficulty}">${lesson.difficulty}</span>
      <span class="lesson-duration">⏱️ ${lesson.duration}</span>
      ${lesson.isPremium ? '<span class="badge-vip">VIP ONLY</span>' : ''}
    </div>
    <h2 style="font-size: 1.4rem; font-weight: 900; margin-bottom: 14px;">${escapeHtml(lesson.title)}</h2>
    <p style="color: var(--text-secondary); margin-bottom: 20px; font-size: 0.95rem; line-height: 1.6;">${escapeHtml(lesson.summary)}</p>

    <h4 style="font-size: 1rem; font-weight: 800; color: var(--ff-orange); margin-bottom: 10px;">📋 Step-by-Step Instructions</h4>
    <div style="background: var(--bg-input); border-radius: var(--radius-md); padding: 16px; margin-bottom: 20px;">
      ${lesson.instructions.map(inst => `
        <div style="font-size: 0.9rem; margin-bottom: 10px; color: #FFF; line-height: 1.5;">${escapeHtml(inst)}</div>
      `).join("")}
    </div>

    <h4 style="font-size: 1rem; font-weight: 800; color: var(--ff-gold); margin-bottom: 10px;">🎯 Practical Training Ground Drills</h4>
    <div style="background: rgba(255, 179, 0, 0.08); border: 1px solid rgba(255, 179, 0, 0.2); border-radius: var(--radius-md); padding: 16px; margin-bottom: 24px;">
      ${lesson.exercises.map(ex => `
        <div style="font-size: 0.88rem; margin-bottom: 8px; color: #FFE082;">• ${escapeHtml(ex)}</div>
      `).join("")}
    </div>

    <div style="display: flex; gap: 12px; justify-content: flex-end;">
      <button class="btn btn-secondary" onclick="closeModal('modal-lesson-detail')">Close</button>
      <button class="btn ${isCompleted ? 'btn-secondary' : 'btn-primary'}" onclick="toggleLessonHandler('${lesson.id}')">
        ${isCompleted ? '↩️ Mark Incomplete' : '✅ Mark Lesson Completed'}
      </button>
    </div>
  `;

  openModal("modal-lesson-detail");
}

function toggleLessonHandler(lessonId) {
  const result = window.FF_AUTH.toggleLessonComplete(lessonId);
  showToast(result ? "Lesson Marked as Completed! 🎯" : "Lesson reset to pending.");
  closeModal("modal-lesson-detail");
  renderAcademyLessons();
  renderDashboard();
}

function setupWeapons() {
  renderWeaponsList();
  const search = document.getElementById("weapon-search-input");
  if (search) {
    search.addEventListener("input", renderWeaponsList);
  }
}

function renderWeaponsList() {
  const container = document.getElementById("weapons-list-container");
  if (!container) return;

  const weapons = window.FF_DB.getWeapons();
  const query = (document.getElementById("weapon-search-input")?.value || "").toLowerCase();

  const filtered = weapons.filter(w => 
    w.name.toLowerCase().includes(query) || w.category.toLowerCase().includes(query)
  );

  container.innerHTML = filtered.map(w => `
    <div class="weapon-card">
      <div class="weapon-header">
        <div>
          <span class="weapon-name">${escapeHtml(w.name)}</span>
          <span style="font-size: 0.75rem; color: var(--text-muted); margin-left: 8px;">${escapeHtml(w.category)}</span>
        </div>
        <span class="weapon-type-badge">${w.armorPen > 0 ? `🛡️ ${w.armorPen}% Armor Pen` : 'Standard'}</span>
      </div>
      <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 14px;">${escapeHtml(w.description)}</p>

      <div class="weapon-stat-row">
        <span>Damage</span>
        <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: ${w.damage}%;"></div></div>
        <strong style="text-align: right; color: #FFF;">${w.damage}</strong>
      </div>
      <div class="weapon-stat-row">
        <span>Rate of Fire</span>
        <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: ${w.rateOfFire}%; background: var(--ff-orange);"></div></div>
        <strong style="text-align: right; color: #FFF;">${w.rateOfFire}</strong>
      </div>
      <div class="weapon-stat-row">
        <span>Range</span>
        <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: ${w.range}%; background: var(--ff-gold);"></div></div>
        <strong style="text-align: right; color: #FFF;">${w.range}</strong>
      </div>
      <div class="weapon-stat-row">
        <span>Accuracy</span>
        <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: ${w.accuracy}%; background: var(--ff-cyan);"></div></div>
        <strong style="text-align: right; color: #FFF;">${w.accuracy}</strong>
      </div>
    </div>
  `).join("");
}

function setupPricingAndPayments() {
  renderPricingPlans();

  const receiptInput = document.getElementById("pay-receipt-file");
  if (receiptInput) {
    receiptInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (loadEvent) => {
          uploadedReceiptData = loadEvent.target.result;
          const previewImg = document.getElementById("receipt-preview");
          if (previewImg) {
            previewImg.src = uploadedReceiptData;
            previewImg.style.display = "block";
          }
          document.getElementById("receipt-dropzone-label").textContent = `Selected: ${file.name}`;
        };
        reader.readAsDataURL(file);
      }
    });
  }

  const paymentForm = document.getElementById("moniepoint-payment-form");
  if (paymentForm) {
    paymentForm.addEventListener("submit", (e) => {
      e.preventDefault();
      handlePaymentSubmission();
    });
  }

  const btnCopyAccount = document.getElementById("btn-copy-acc-num");
  if (btnCopyAccount) {
    btnCopyAccount.addEventListener("click", () => {
      const settings = window.FF_DB.getAppSettings();
      copyText(settings.accountNumber, "Moniepoint Account Number");
    });
  }
}

function renderPricingPlans() {
  const container = document.getElementById("pricing-cards-container");
  if (!container) return;

  const plans = window.FF_DB.getPlans().filter(p => p.active);
  const isVip = window.FF_AUTH.isPremium();

  container.innerHTML = plans.map(plan => `
    <div class="pricing-card ${plan.popular ? 'popular' : ''}">
      ${plan.popular ? '<div class="pricing-badge-popular">MOST POPULAR</div>' : ''}
      <div>
        <h3 class="plan-name">${escapeHtml(plan.name)}</h3>
        <div class="plan-price-box">
          <div class="plan-price-ngn">₦${plan.priceNGN.toLocaleString()}</div>
          <div class="plan-price-usd">$${plan.priceUSD} USD / ${plan.durationDays >= 365 ? 'Lifetime' : (plan.durationDays + ' Days')}</div>
        </div>
        <ul class="plan-features">
          ${plan.features.map(f => `
            <li>
              <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
              ${escapeHtml(f)}
            </li>
          `).join("")}
        </ul>
      </div>
      <div>
        <button class="btn ${plan.popular ? 'btn-primary' : 'btn-secondary'} btn-full" onclick="startMoniepointPayment('${plan.id}')">
          ${isVip ? 'Renew / Extend VIP' : '⚡ PAY WITH MONIEPOINT'}
        </button>
      </div>
    </div>
  `).join("");
}

function startMoniepointPayment(planId) {
  const user = window.FF_AUTH.getCurrentUser();
  if (!user) {
    showToast("Please log in or sign up before subscribing!", false);
    openModal("modal-auth-login");
    return;
  }

  const plans = window.FF_DB.getPlans();
  selectedPlanForPayment = plans.find(p => p.id === planId);
  if (!selectedPlanForPayment) return;

  const settings = window.FF_DB.getAppSettings();

  document.getElementById("modal-pay-plan-name").textContent = selectedPlanForPayment.name;
  document.getElementById("modal-pay-price").textContent = `₦${selectedPlanForPayment.priceNGN.toLocaleString()} ($${selectedPlanForPayment.priceUSD})`;
  document.getElementById("modal-pay-bank-name").textContent = settings.bankName;
  document.getElementById("modal-pay-acc-num").textContent = settings.accountNumber;
  document.getElementById("modal-pay-acc-name").textContent = settings.accountName;

  document.getElementById("pay-sender-name").value = user.ign || "";
  document.getElementById("pay-session-ref").value = "";
  uploadedReceiptData = "";
  const previewImg = document.getElementById("receipt-preview");
  if (previewImg) previewImg.style.display = "none";
  document.getElementById("receipt-dropzone-label").textContent = "Tap to browse receipt screenshot";

  openModal("modal-moniepoint-transfer");
}

function handlePaymentSubmission() {
  const user = window.FF_AUTH.getCurrentUser();
  if (!user || !selectedPlanForPayment) return;

  const senderName = document.getElementById("pay-sender-name").value.trim();
  const sessionRef = document.getElementById("pay-session-ref").value.trim();
  const settings = window.FF_DB.getAppSettings();

  if (!senderName || !sessionRef) {
    showToast("Please provide sender name and transaction reference/session ID.", false);
    return;
  }

  const paymentRecord = {
    id: "FFC-PAY-" + Math.floor(10000 + Math.random() * 90000),
    userId: user.uid,
    userEmail: user.email,
    userIgn: user.ign,
    planId: selectedPlanForPayment.id,
    planName: selectedPlanForPayment.name,
    amount: `₦${selectedPlanForPayment.priceNGN.toLocaleString()} ($${selectedPlanForPayment.priceUSD})`,
    currency: "NGN",
    bankName: settings.bankName,
    accountNumber: settings.accountNumber,
    senderName: senderName,
    sessionReference: sessionRef,
    receiptImage: uploadedReceiptData,
    status: "pending",
    submittedAt: new Date().toISOString(),
    reviewedAt: null,
    adminNotes: ""
  };

  window.FF_DB.savePayment(paymentRecord);

  window.FF_DB.sendNotification({
    userId: user.uid,
    title: "Payment Submitted for Verification",
    message: `Your payment of ${paymentRecord.amount} (Ref: ${paymentRecord.id}) has been sent to our admin team. Verification usually takes 5-15 minutes.`,
    type: "payment"
  });

  closeModal("modal-moniepoint-transfer");

  document.getElementById("confirm-payment-id").textContent = paymentRecord.id;
  document.getElementById("confirm-payment-amount").textContent = paymentRecord.amount;
  openModal("modal-payment-success");

  renderDashboard();
}

function setupDashboard() {
  const btnEditProfile = document.getElementById("dash-btn-edit-profile");
  if (btnEditProfile) {
    btnEditProfile.addEventListener("click", () => {
      const user = window.FF_AUTH.getCurrentUser();
      if (!user) return;
      document.getElementById("edit-ign").value = user.ign || "";
      document.getElementById("edit-ffuid").value = user.ffUid || "";
      document.getElementById("edit-rank").value = user.rank || "Heroic";
      document.getElementById("edit-role").value = user.role || "Rusher";
      openModal("modal-edit-profile");
    });
  }

  const formEditProfile = document.getElementById("form-edit-profile");
  if (formEditProfile) {
    formEditProfile.addEventListener("submit", (e) => {
      e.preventDefault();
      const ign = document.getElementById("edit-ign").value.trim();
      const ffUid = document.getElementById("edit-ffuid").value.trim();
      const rank = document.getElementById("edit-rank").value;
      const role = document.getElementById("edit-role").value;

      window.FF_AUTH.updateProfile({ ign, ffUid, rank, role });
      showToast("Profile updated successfully!");
      closeModal("modal-edit-profile");
      renderDashboard();
    });
  }
}

function renderDashboard() {
  const user = window.FF_AUTH.getCurrentUser();
  const guestBanner = document.getElementById("dash-guest-state");
  const authContent = document.getElementById("dash-authenticated-state");

  if (!user) {
    if (guestBanner) guestBanner.style.display = "block";
    if (authContent) authContent.style.display = "none";
    return;
  }

  if (guestBanner) guestBanner.style.display = "none";
  if (authContent) authContent.style.display = "block";

  document.getElementById("dash-ign").textContent = user.ign;
  document.getElementById("dash-ffuid").textContent = `UID: ${user.ffUid}`;
  document.getElementById("dash-rank-badge").textContent = `🎖️ ${user.rank} • ${user.role}`;

  const subStatusBadge = document.getElementById("dash-sub-badge");
  const subExpiryText = document.getElementById("dash-sub-expiry");
  const isVip = window.FF_AUTH.isPremium();

  if (isVip) {
    subStatusBadge.className = "badge-status-approved";
    subStatusBadge.textContent = "VIP ACTIVE";
    if (user.expiresAt) {
      const expiry = new Date(user.expiresAt);
      subExpiryText.textContent = `Valid until: ${expiry.toLocaleDateString()}`;
    } else {
      subExpiryText.textContent = "Lifetime Access Unlocked";
    }
  } else {
    subStatusBadge.className = "badge-status-rejected";
    subStatusBadge.textContent = "FREE PLAN";
    subExpiryText.textContent = "Upgrade to Premium for unlimited sensitivity and VIP lessons.";
  }

  const totalLessons = window.FF_DB.getLessons().length;
  const completedCount = (user.completedLessons || []).length;
  const progressPercent = Math.round((completedCount / (totalLessons || 1)) * 100);

  document.getElementById("dash-stat-gens").textContent = user.generationsCount || 0;
  document.getElementById("dash-stat-lessons").textContent = `${completedCount} / ${totalLessons}`;
  document.getElementById("dash-stat-progress").textContent = `${progressPercent}%`;

  renderSavedSensitivityProfiles(user.uid);
  renderUserPaymentHistory(user.uid);
}

function renderSavedSensitivityProfiles(userId) {
  const container = document.getElementById("dash-saved-profiles-list");
  if (!container) return;

  const profiles = window.FF_DB.getSensitivityProfiles(userId);
  if (profiles.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 24px; color: var(--text-muted); font-size: 0.85rem;">No saved sensitivity profiles yet. Use the Sensitivity Generator to calculate and save your first setup!</div>`;
    return;
  }

  container.innerHTML = profiles.map(p => `
    <div class="card" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
      <div>
        <h4 style="font-size: 1rem; font-weight: 800; color: #FFF;">${escapeHtml(p.name)}</h4>
        <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 4px;">
          Gen: <strong style="color: var(--ff-orange);">${p.general}</strong> • RedDot: <strong>${p.redDot}</strong> • 2X: <strong>${p.scope2x}</strong> • 4X: <strong>${p.scope4x}</strong> • DPI: <strong>${p.dpi}</strong>
        </div>
      </div>
      <div style="display: flex; gap: 8px;">
        <button class="btn btn-secondary btn-sm" onclick="applySavedProfile('${p.id}')">Apply</button>
        <button class="btn btn-secondary btn-sm" onclick="copySavedProfile('${p.id}')">Copy</button>
        <button class="btn btn-secondary btn-sm" style="color: var(--ff-red);" onclick="deleteSavedProfile('${p.id}')">✕</button>
      </div>
    </div>
  `).join("");
}

function applySavedProfile(profileId) {
  const profile = window.FF_DB.getSensitivityProfiles().find(p => p.id === profileId);
  if (!profile) return;
  currentGeneratedSens = profile;
  switchView("generator");
  renderSensitivityResults(profile);
  showToast("Profile applied to generator!");
}

function copySavedProfile(profileId) {
  const p = window.FF_DB.getSensitivityProfiles().find(p => p.id === profileId);
  if (!p) return;
  const text = `🔥 FREE FIRE COACH - ${p.name}
General: ${p.general} | Red Dot: ${p.redDot} | 2X: ${p.scope2x} | 4X: ${p.scope4x} | Sniper: ${p.sniperScope} | Free Look: ${p.freeLook} | DPI: ${p.dpi} | Fire Button: ${p.fireButtonSize}%`;
  copyText(text, "Sensitivity Profile");
}

function deleteSavedProfile(profileId) {
  window.FF_DB.deleteSensitivityProfile(profileId);
  showToast("Profile deleted.");
  const user = window.FF_AUTH.getCurrentUser();
  if (user) renderSavedSensitivityProfiles(user.uid);
}

function renderUserPaymentHistory(userId) {
  const container = document.getElementById("dash-payments-table-body");
  if (!container) return;

  const payments = window.FF_DB.getPayments().filter(p => p.userId === userId);
  if (payments.length === 0) {
    container.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 24px; color: var(--text-muted);">No payment transactions submitted yet.</td></tr>`;
    return;
  }

  container.innerHTML = payments.map(p => {
    let statusBadge = `<span class="badge-status-pending">Pending Review</span>`;
    if (p.status === "approved") {
      statusBadge = `<span class="badge-status-approved">Approved (VIP Active)</span>`;
    } else if (p.status === "rejected") {
      statusBadge = `<span class="badge-status-rejected">Rejected</span>`;
    }

    return `
      <tr>
        <td><strong>${escapeHtml(p.id)}</strong></td>
        <td>${escapeHtml(p.planName)}</td>
        <td>${escapeHtml(p.amount)}</td>
        <td>${statusBadge}</td>
        <td>${new Date(p.submittedAt).toLocaleDateString()}</td>
      </tr>
    `;
  }).join("");
}

function setupAuthUI() {
  const loginForm = document.getElementById("form-login");
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = document.getElementById("login-email").value;
      const pass = document.getElementById("login-password").value;
      try {
        await window.FF_AUTH.login(email, pass);
        showToast("Logged in successfully! 🔥");
        closeModal("modal-auth-login");
      } catch (err) {
        showToast(err.message, false);
      }
    });
  }

  const signupForm = document.getElementById("form-signup");
  if (signupForm) {
    signupForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = document.getElementById("signup-email").value;
      const pass = document.getElementById("signup-password").value;
      const ign = document.getElementById("signup-ign").value;
      const ffUid = document.getElementById("signup-ffuid").value;
      const rank = document.getElementById("signup-rank").value;
      const role = document.getElementById("signup-role").value;

      try {
        await window.FF_AUTH.signUp(email, pass, ign, ffUid, rank, role);
        showToast("Welcome to Free Fire Coach! 🔥");
        closeModal("modal-auth-signup");
      } catch (err) {
        showToast(err.message, false);
      }
    });
  }

  const btnLogout = document.getElementById("dash-btn-logout");
  if (btnLogout) {
    btnLogout.addEventListener("click", () => {
      window.FF_AUTH.logout();
      showToast("Logged out successfully.");
      switchView("home");
    });
  }
}

function setupNotificationChecker() {
  const btnNotif = document.getElementById("header-notif-btn");
  if (!btnNotif) return;

  btnNotif.addEventListener("click", () => {
    const user = window.FF_AUTH.getCurrentUser();
    const notifs = window.FF_DB.getNotifications(user ? user.uid : "all");
    const listElem = document.getElementById("notif-modal-list");

    if (listElem) {
      if (notifs.length === 0) {
        listElem.innerHTML = `<div style="text-align: center; padding: 24px; color: var(--text-muted);">No new notifications.</div>`;
      } else {
        listElem.innerHTML = notifs.map(n => `
          <div style="background: var(--bg-input); border-radius: var(--radius-sm); padding: 12px; margin-bottom: 10px; border-left: 3px solid var(--ff-red);">
            <div style="font-size: 0.9rem; font-weight: 800; color: #FFF; margin-bottom: 4px;">${escapeHtml(n.title)}</div>
            <div style="font-size: 0.82rem; color: var(--text-secondary);">${escapeHtml(n.message)}</div>
            <div style="font-size: 0.72rem; color: var(--text-muted); margin-top: 6px;">${new Date(n.createdAt).toLocaleTimeString()}</div>
          </div>
        `).join("");
      }
    }

    openModal("modal-notifications");
  });
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add("active");
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove("active");
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

window.switchView = switchView;
window.openModal = openModal;
window.closeModal = closeModal;
window.startMoniepointPayment = startMoniepointPayment;
window.openLessonDetail = openLessonDetail;
window.toggleLessonHandler = toggleLessonHandler;
window.copyText = copyText;
window.applySavedProfile = applySavedProfile;
window.copySavedProfile = copySavedProfile;
window.deleteSavedProfile = deleteSavedProfile;
